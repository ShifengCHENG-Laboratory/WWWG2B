#python3 /public/agis/chengshifeng_group/fengcong/WGRS/software/Fc-code/excel_haplotype_update_for_visualizetion/excel_haplotype.py \
#    -v TraesCS7A02G115400.g2k.SNPINDEL.sort.AC2_retain.vcf.gz \
#    -D ./depth_data/ \
#    -r chr7A:71667854-71672886  \
#    -o TraesCS7A02G115400.g2k.SNPINDEL.AC2 \
#    -I TraesCS7A02G115400.g2k.SNPINDEL.sort.AC2_retain.moreinf.txt \
#    -i 1047_Inf.txt 
#

Rscript /public/agis/chengshifeng_group/fengcong/WGRS/software/Fc-code/excel_haplotype_update_for_visualizetion/HAPPE.haplotype.v0705.R  \
    -H TraesCS7A02G115400.g2k.SNPINDEL.AC2.heat  \
    -t TraesCS7A02G115400.g2k.SNPINDEL.AC2.newick  \
    -c TraesCS7A02G115400.g2k.SNPINDEL.AC2.cluster  \
    -g IWGSC_v1.1_HC_20170706.gff3  \
    -s pca_1047.pop.xls   \
    -r chr7A:71667854-71672886  \
    -o TraesCS7A02G115400.g2k.HAPPE


Rscript /public/agis/chengshifeng_group/fengcong/WGRS/software/Fc-code/excel_haplotype_update_for_visualizetion/HAPPE.depth.v0705.R \
    -H TraesCS7A02G115400.depth.txt  \
    -t TraesCS7A02G115400.g2k.SNPINDEL.AC2.newick  \
    -c TraesCS7A02G115400.g2k.SNPINDEL.AC2.cluster  \
    -g IWGSC_v1.1_HC_20170706.gff3  \
    -s pca_1047.pop.xls  \
    -r chr7A:71667854-71672886  \
    -o TraesCS7A02G115400.g2k.depth.HAPPE
    
